var searchData=
[
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['rules',['rules',['../namespacegr2jflap.html#a1f275e6ae4855de88fee6d6f262d6476',1,'gr2jflap']]]
];

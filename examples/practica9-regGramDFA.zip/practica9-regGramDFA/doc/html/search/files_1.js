var searchData=
[
  ['gr_2ecpp',['GR.cpp',['../_g_r_8cpp.html',1,'']]],
  ['gr_2ehpp',['GR.hpp',['../_g_r_8hpp.html',1,'']]],
  ['gr2jflap_2epy',['gr2jflap.py',['../gr2jflap_8py.html',1,'']]]
];

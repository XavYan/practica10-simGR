var searchData=
[
  ['new_5fid',['new_id',['../classstate__t.html#a541e80fbf886c337d53c0e5614f0c38b',1,'state_t']]]
];

var searchData=
[
  ['rules',['rules',['../namespacegr2jflap.html#a1f275e6ae4855de88fee6d6f262d6476',1,'gr2jflap']]]
];
